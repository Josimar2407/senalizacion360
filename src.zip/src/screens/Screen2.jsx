import React, { useMemo, useRef } from 'react';
import '../styles/brand.css';
import SectionHeader from '../components/SectionHeader';
import usePreserveScrollOnDeps from '../hooks/usePreserveScrollOnDeps';
import { cleanGenericBody, extractSinglePercent, stripLeadingPercent } from '../utils/formatUtils';

/* ========= helpers de vigencia (robustos) ========= */
function excelSerialToDate(n){
  const num = typeof n === 'string' ? Number(n) : n;
  if (!isFinite(num)) return null;
  const ms = (num - 25569) * 86400 * 1000; // base 1899-12-30
  const d = new Date(ms);
  return isNaN(d.getTime()) ? null : d;
}
function parseDateString(s){
  if (typeof s !== 'string') return null;
  const t = s.trim();

  // yyyy-mm-dd / yyyy/mm/dd
  let m = t.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  if (m){
    const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    return isNaN(d.getTime()) ? null : d;
  }
  // dd/mm/yyyy / dd-mm-yyyy
  m = t.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (m){
    const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
    return isNaN(d.getTime()) ? null : d;
  }
  // Fallback
  const d = new Date(t);
  return isNaN(d.getTime()) ? null : d;
}
function toDateMaybe(v){
  if (v === 0 || v){
    if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
    if (typeof v === 'number') return excelSerialToDate(v);
    if (typeof v === 'string'){
      if (/^\d{4,6}$/.test(v)){ // serial excel en string
        const d = excelSerialToDate(v);
        if (d) return d;
      }
      return parseDateString(v);
    }
  }
  return null;
}
function fmt(d){
  const dd = String(d.getDate()).padStart(2,'0');
  const mm = String(d.getMonth()+1).padStart(2,'0');
  const yy = d.getFullYear();
  return `${dd}/${mm}/${yy}`;
}
function pickDateFields(p){
  const candidates = {
    desde: ['desde','inicio','vig_ini','vigencia_inicio','fecha_inicio','fecha_desde','vigini'],
    hasta: ['hasta','fin','vig_fin','vigencia_fin','fecha_fin','fecha_hasta','vigfin'],
  };
  const out = { desde: p?.desde, hasta: p?.hasta };
  if (!out.desde){
    for (const k of candidates.desde){ if (p && p[k] != null){ out.desde = p[k]; break; } }
  }
  if (!out.hasta){
    for (const k of candidates.hasta){ if (p && p[k] != null){ out.hasta = p[k]; break; } }
  }
  return out;
}
function vigenciaUnificadaTxt(p){
  // Texto directo si existe
  if (p?.vigencia && String(p.vigencia).trim().length > 4){
    return String(p.vigencia).trim();
  }
  // Intentar con campos comunes
  const { desde, hasta } = pickDateFields(p);
  const d1 = toDateMaybe(desde);
  const d2 = toDateMaybe(hasta);

  if (d1 && d2) return `${fmt(d1)} al ${fmt(d2)}`;
  if (d1 && !d2) return fmt(d1);
  if (d2 && !d1) return fmt(d2);

  // Extraer rango desde un texto
  if (typeof p?.vigencia === 'string'){
    const m = p.vigencia.match(/(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}).+?(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})/);
    if (m){
      const a = parseDateString(m[1]);
      const b = parseDateString(m[2]);
      if (a && b) return `${fmt(a)} al ${fmt(b)}`;
    }
  }
  // Nada interpretable → ocultar
  return '';
}

function IconExcel() {
  return (
    <span className="excel-icon" aria-hidden>
      <svg width="22" height="22" viewBox="0 0 24 24" role="img" aria-label="Excel">
        <rect x="1" y="1" width="22" height="22" rx="4" ry="4" fill="#107C41" />
        <path d="M7 7l4 5-4 5h3l4-5-4-5H7z" fill="#fff" />
      </svg>
    </span>
  );
}

export default function Screen2({
  promoListAll, limitP2, setLimitP2,
  checkedP2, setCheckedP2,
  selectedDepts,
  onReset, onExport, onExportExcel,
}){
  const promoList = useMemo(() => promoListAll.slice(0, limitP2), [promoListAll, limitP2]);
  const listRef = useRef(null);
  const { runScrollOnDeps: _ignored } = usePreserveScrollOnDeps(listRef, [promoList.length]);

  const css = `
    :root { --tabs-h: 64px; }

    /* ========== CAMBIO CLAVE AQUÍ PARA LAS 2 COLUMNAS ========== */
    .promo-wrap { 
      padding-right:4px; 
      padding-bottom:calc(var(--tabs-h) + 24px); 
      
      /* FORZAR LAYOUT DE CUADRÍCULA (GRID) */
      display: grid;
      /* Define 2 columnas de igual tamaño (1fr 1fr) y un espacio (gap) de 12px */
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      padding: 12px; /* Añade un padding general para que las tarjetas no toquen los bordes */
    }
    /* ========================================================== */

    .sign-card {
      border:2px solid #ef4444;
      border-radius:12px;
      background:#fff;
      /* ELIMINAR LOS MÁRGENES VERTICALES QUE USABA LA LISTA */
      margin:0; 
      overflow:hidden;
    }

    /* ===== Encabezado de promoción =====
       Franja roja con el porcentaje o tipo de oferta. */
    .sign-head {
      background:#ef4444;
      color:#fff;
      padding:8px 12px;
      display:flex;
      align-items:center;
      gap:10px;
      border-top-left-radius:10px;
      border-top-right-radius:10px;
      font-weight:800;
      font-size:18px;
    }

    /* ===== Cuerpo: SOLO promoción genérica y vigencia ===== */
    .sign-body {
      padding:16px 16px 20px;
      text-align:left;
    }
    .sign-title {
      font-weight:800;
      text-transform:uppercase;
      line-height:1.3;
      color:#111;
      font-size:1rem;
      margin-bottom:6px;
      word-break:break-word;
    }
    .sign-vig {
      font-size:.9rem;
      font-weight:600;
      color:#374151;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
  `;

  const loadMoreP2 = () => {
    if (limitP2 < promoListAll.length) setLimitP2(n => n + 30);
  };

  return (
    <div className="px-4" style={{ minHeight: 'calc(100vh - 56px)' }}>
      <div className="flex flex-col h-full">
        <style>{css}</style>

        <SectionHeader
          right={<span>{promoListAll.length} promociones · {selectedDepts.length} depto(s)</span>}
        />

        {/* Botones (clases compartidas de brand.css) */}
        <div className="toolbar" style={{ margin: '6px 0 4px' }}>
          <button className="btn-pill btn-pill-dark same-height" onClick={onExportExcel}>
            <IconExcel /> Exportar Excel
          </button>
          <button className="btn-pill btn-pill-dark same-height" onClick={onExport}>
            Terminar señalización
          </button>
          <div className="toolbar-right">
            <button className="btn-pill btn-red same-height btn-compact" onClick={onReset}>
              Reiniciar
            </button>
          </div>
        </div>

        <div ref={listRef} className="promo-wrap">
          {promoList.map((p) => {
            const promoKey = p.key;
            const percent = extractSinglePercent(p.gen);
            const header = percent != null ? `${percent}% de descuento` : 'OFERTA';
            const body = stripLeadingPercent(cleanGenericBody(p.gen));
            const vig = vigenciaUnificadaTxt(p);

            return (
              <div key={promoKey} className="sign-card">
                {/* Encabezado rojo de promoción */}
                <div className="sign-head">
                  <input
                    type="checkbox"
                    checked={!!checkedP2[promoKey]}
                    onChange={(e) =>
                      setCheckedP2((prev) => ({ ...prev, [promoKey]: e.target.checked }))
                    }
                  />
                  <div className="hdr">{header}</div>
                </div>

                {/* Cuerpo limpio: solo promoción + vigencia */}
                <div className="sign-body">
                  <div className="sign-title">{body || p.gen}</div>
                  {vig && <div className="sign-vig">Vigencia: {vig}</div>}
                </div>
              </div>
            );
          })}

          {promoListAll.length > promoList.length && (
            <div style={{ textAlign: 'center', padding: '12px 0 84px' }}>
              <button className="btn-pill btn-pill-dark same-height" onClick={loadMoreP2}>
                Cargar 30 más
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
