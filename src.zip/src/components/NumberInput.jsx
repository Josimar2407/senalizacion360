import React from 'react';
export default function NumberInput({ value, onChange, maxDigits=2, width=56, fontSize='0.9rem', ariaLabel='' }){
  const handle = (e)=>{
    const v = e.target.value.replace(/[^0-9]/g,'');
    const trimmed = v.slice(0, maxDigits);
    onChange && onChange(trimmed);
  };
  return (
    <input
      aria-label={ariaLabel}
      type='text'
      inputMode='numeric'
      pattern='[0-9]*'
      style={{ width, textAlign:'center', fontSize, padding:'6px 8px', border:'1px solid #e5e7eb', borderRadius:8 }}
      value={String(value ?? '')}
      onChange={handle}
      onFocus={(e)=> e.target.select()}
    />
  );
}
