export const toNum = (x)=> Number(x||0);
export function stripLeadingPercent(txt){
  if(!txt) return "";
  return String(txt).replace(/^\s*\d+\s*%\s*/,"").trim();
}
export function cleanGenericBody(txt){
  return String(txt||"").trim();
}
export function extractSinglePercent(txt){
  const m = String(txt||"").match(/(\d{1,3})\s*%/);
  return m? Number(m[1]) : null;
}
