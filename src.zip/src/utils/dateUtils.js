export function toDate(v){
  if(!v) return null;
  const d = (v instanceof Date)? v : new Date(v);
  return isNaN(d) ? null : d;
}
export function fmtDmy(d){
  if(!d) return "";
  const dd = String(d.getDate()).padStart(2,"0");
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const yy = d.getFullYear();
  return `${dd}/${mm}/${yy}`;
}
export function vigenciaUnificada(desde,hasta){
  if(!desde && !hasta) return "";
  if(desde && hasta) return `${desde} al ${hasta}`;
  return desde || hasta || "";
}
export function fechaNombreArchivoLocal(){
  const d = new Date();
  const pad = (n)=> String(n).padStart(2,"0");
  return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}
